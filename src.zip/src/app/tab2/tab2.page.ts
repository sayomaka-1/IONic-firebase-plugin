import { Component } from '@angular/core';
import { Firebase } from '@ionic-native/firebase/ngx'

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  
  constructor(private firebase : Firebase){}

  ionViewDidEnter(){
    console.log("tab 2")
    this.firebase.setScreenName("tab 2");
  }

  
  redeem() {
    console.log("Redeemed");
    this.firebase
      .logEvent("REDEEM_COIN",{REDEEM_TYPE:"redeem",VALUE:5})
      .then((res: any) => console.log(res))
      .catch((error: any) => console.error(error));
  }
  Transfer() {
    console.log("Transfer");
    this.firebase
      .logEvent("REDEEM_COIN",{REDEEM_TYPE:"transfer",VALUE:10})
      .then((res: any) => console.log(res))
      .catch((error: any) => console.error(error));
  }
  Scan() {
    console.log("Scan");
    this.firebase
      .logEvent("REDEEM_COIN",{REDEEM_TYPE:"scan",VALUE:15})
      .then((res: any) => console.log(res))
      .catch((error: any) => console.error(error));
  }
  Sample() {
    console.log("sample");
    this.firebase
      .logEvent("REDEEM_COIN",{REDEEM_TYPE:"sample",VALUE: 20})
      .then((res: any) => console.log(res))
      .catch((error: any) => console.error(error));
  }
}
